package com.syc.finance.v1.bharat.exceptions;

public class ServiceProviderIsNullException extends RuntimeException{

    public ServiceProviderIsNullException(String message){
        super(message);
    }
}
