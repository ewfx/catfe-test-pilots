package com.syc.finance.v1.bharat.dto.TransferMoney;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransferMoneyResponse {

    private String responseMessage;
}
