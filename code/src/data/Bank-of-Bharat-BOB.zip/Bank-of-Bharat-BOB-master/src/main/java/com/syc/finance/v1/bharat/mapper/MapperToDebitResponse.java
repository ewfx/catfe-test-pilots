package com.syc.finance.v1.bharat.mapper;

public class MapperToDebitResponse {
}
