package com.syc.finance.v1.bharat.exceptions;

public class UpiAlreadyExist extends RuntimeException{

    public UpiAlreadyExist(String message){

        super(message);
    }

}
