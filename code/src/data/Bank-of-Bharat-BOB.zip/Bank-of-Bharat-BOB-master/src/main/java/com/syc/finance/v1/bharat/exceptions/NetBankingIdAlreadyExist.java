package com.syc.finance.v1.bharat.exceptions;

public class NetBankingIdAlreadyExist extends RuntimeException{

    public NetBankingIdAlreadyExist(String message){
        super(message);
    }
}
