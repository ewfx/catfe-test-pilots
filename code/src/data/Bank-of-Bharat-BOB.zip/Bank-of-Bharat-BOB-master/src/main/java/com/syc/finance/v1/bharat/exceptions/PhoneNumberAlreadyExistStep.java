package com.syc.finance.v1.bharat.exceptions;

public class PhoneNumberAlreadyExistStep extends RuntimeException{

    public PhoneNumberAlreadyExistStep(String message){
        super(message);
    }
}
