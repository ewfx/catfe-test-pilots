package com.syc.finance.v1.bharat.exceptions;

public class AccountBalanceMinimumSteps extends RuntimeException{

    public AccountBalanceMinimumSteps(String mesg){
        super(mesg);
    }

}
